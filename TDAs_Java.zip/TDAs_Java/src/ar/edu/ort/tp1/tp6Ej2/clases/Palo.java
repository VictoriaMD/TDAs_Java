package ar.edu.ort.tp1.tp6Ej2.clases;

public interface Palo {}
