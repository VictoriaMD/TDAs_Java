package ar.edu.ort.tp1.tp6Ej2.clases;

public class Comodin implements Naipe {

	@Override
	public String getDescripcion() {
		return "Comodin";
	}

}
