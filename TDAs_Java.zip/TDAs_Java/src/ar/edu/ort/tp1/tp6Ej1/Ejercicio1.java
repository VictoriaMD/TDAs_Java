package ar.edu.ort.tp1.tp6Ej1;

import ar.edu.ort.tp1.tdas.implementaciones.PilaNodos;
import ar.edu.ort.tp1.tdas.interfaces.Pila;
import ar.edu.ort.tp1.tp6Ej1.clases.FabricanteDePelotas;
import ar.edu.ort.tp1.tp6Ej1.clases.PelotaDeTenis;
import ar.edu.ort.tp1.tp6Ej1.clases.TuboPelotasDeTenis;
import ar.edu.ort.tp1.tp6Ej1.clases.PelotasPorUso;



public class Ejercicio1 {

	public static void main(String[] args) {
		// Fabricante
		TuboPelotasDeTenis tuboDePelotas = FabricanteDePelotas.fabricarTubo();
		// Jugador
		PelotaDeTenis pelota = tuboDePelotas.extraer();
		pelota.usar();
		tuboDePelotas.guardar(pelota);
		
		listarContenidoTubo(tuboDePelotas);
	}
	
	private static void listarContenidoTubo(TuboPelotasDeTenis tuboDePelotas) {
		PelotaDeTenis pelota = null;
		
		PelotasPorUso listaPorUso = new PelotasPorUso();
		while(!tuboDePelotas.estaVacio()) {
			pelota = tuboDePelotas.extraer();
			System.out.println(pelota);
			listaPorUso.add(pelota);	// agrega ordenadamente en la lista
		}		
		/* tenemos cargadas las pelotas en la lista
		y quedan dentro de la lista
		Luego pasamos el contenido de la lista 
		que ya viene ordenada como lo necesitamos, a la pila (tubo)*/
		for (PelotaDeTenis unaPelota : listaPorUso) {
			tuboDePelotas.guardar(unaPelota);
		}
	}


}
