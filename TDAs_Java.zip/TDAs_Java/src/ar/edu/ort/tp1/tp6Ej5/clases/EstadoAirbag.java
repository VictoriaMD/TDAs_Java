package ar.edu.ort.tp1.tp6Ej5.clases;

public enum EstadoAirbag {
	OK, DEFECTUOSO, NO_POSEE
}
